# Markdown and HTML artifact contract

## Contents

1. [Canonical source](#canonical-source)
2. [Required HTML](#required-html)
3. [Learning interactions](#learning-interactions)
4. [Accessibility](#accessibility)
5. [Visual and source provenance](#visual-and-source-provenance)
6. [Optional Flint chart artifacts](#optional-flint-chart-artifacts)
7. [Build and parity](#build-and-parity)
8. [Acceptance checklist](#acceptance-checklist)

## Canonical source

Every durable instructional document starts as Markdown. Generate an HTML file with the same basename in the same directory.

```text
lessons/0001-index-prefixes.md
lessons/0001-index-prefixes.html
```

Rules:

- Edit Markdown, then regenerate HTML.
- Prefer `node <skill-dir>/scripts/render_markdown.mjs <source.md>` for the bundled self-contained template; set `PRAX_MARKED_PATH` when `marked` is not on the normal Node resolution path.
- Never hand-edit generated teaching content in HTML.
- Put any template/CSS/renderer change in versioned source.
- Record the Markdown source path and SHA-256 in machine-readable HTML metadata and visible page provenance.
- Make regeneration deterministic. Use a fixed timestamp such as `SOURCE_DATE_EPOCH` when byte-for-byte reproducibility matters.
- Fail validation when HTML is missing or the recorded source hash is stale.

## Required HTML

Each standalone page must include:

- `<!doctype html>`, `lang`, UTF-8 charset, viewport, and a specific title;
- a skip link;
- semantic `header`, `nav` when needed, `main`, and `footer` landmarks;
- one `h1`, ordered heading levels, and stable unique anchors;
- readable line length and responsive typography;
- responsive tables or an alternate stacked representation;
- visible focus styles;
- source link, source SHA-256, and generation metadata;
- print styles;
- `prefers-reduced-motion` handling;
- a no-script/static path for essential content;
- no mandatory external CDN, tracking, font, or analytics request.

Optional enhancements that must not gate access:

- generated table of contents;
- theme control respecting system preference;
- reading-progress indicator;
- copy buttons for code;
- collapsible supporting detail;
- local search across a course.

Default authoring dialect is GFM plus reviewed native semantic HTML such as `<details>`, `<summary>`, figures, tables, and ordinary form controls. Do not create `::: custom-directive` syntax, a one-off parser, or a bespoke component framework for a single lesson. If a new semantic block becomes reusable, specify and test it as a versioned renderer feature before using it in canonical content.

## Learning interactions

Use semantic block types with stable IDs:

- `diagnostic`;
- `explanation`;
- `worked-example`;
- `guided-practice`;
- `hint-ladder`;
- `retrieval-check`;
- `teach-back`;
- `transfer-task`;
- `reflection`;
- `review`.

For interactive checks:

1. Show the prompt before the solution.
2. Accept a meaningful attempt where practical.
3. Reveal hints progressively.
4. Explain why the response is correct or incorrect.
5. Keep feedback separate from the answer so another attempt remains possible.
6. Provide an equivalent static workflow.
7. Do not infer or persist mastery from browser interaction alone.

For live chat, use a turn boundary: end on the check and wait. For a self-contained artifact, use a learner-operated reveal and ensure the unrevealed answer is not exposed through accessibility text, metadata, default state, or a no-script shortcut. When that cannot be achieved accessibly, provide the answer key in a clearly separate section and describe the artifact as review material rather than measured retrieval.

Native `<details>` is acceptable for supporting explanation, but do not put essential instructions behind undiscoverable disclosure. If `<details>` contains an answer, label it clearly and place it after the attempt prompt.

## Accessibility

Meet [WCAG 2.2](https://www.w3.org/TR/WCAG22/) AA as a release gate and apply [W3C cognitive-accessibility guidance](https://www.w3.org/TR/coga-usable/) for clear language, predictable navigation, focus support, and memory aids.

### Structure and navigation

- Use landmarks and descriptive headings.
- Keep navigation order consistent.
- Identify the current page in a course.
- Use descriptive link text.
- Provide breadcrumbs or a compact course map for multi-page artifacts.

### Keyboard and focus

- All controls operate without a pointer.
- Focus order follows reading order.
- Focus is never hidden or trapped.
- Dynamic updates announce through an appropriate live region when needed.
- Avoid single-key shortcuts unless remappable or active only on focus.

### Perception and reflow

- Use sufficient contrast and never color alone.
- Allow text resize and 400% zoom without two-dimensional scrolling for ordinary content.
- Do not lock orientation.
- Give media alternatives appropriate to its complexity.
- Keep target sizes and spacing usable.

### Cognitive access

- Prefer short sections and explicit transitions.
- State objectives and what to do next.
- Keep labels and instructions near controls.
- Offer examples, memory aids, and a predictable reveal sequence.
- Avoid time limits; when required, make them adjustable.
- Do not animate, autoplay, or change context unexpectedly.

### Motion and media

- Respect reduced motion.
- Provide captions, transcript, and static sequence when motion carries meaning.
- Never remove information in reduced-motion mode.

Automated scanners are only one check. Test manually with keyboard, zoom/reflow, screen-reader navigation, reduced motion, print, scripts disabled, and representative learners.

## Visual and source provenance

For every significant visual or interactive artifact, preserve:

```text
learning objective
semantic brief or storyboard
source documents/data/URLs
authoring or generation tool and version
editable source path
render command/environment
output dimensions
attribution or license
last verification date
known limitations
```

Place factual citations close to the supported claim or figure. Distinguish sourced fact, inference, and illustrative example.

## Optional Flint chart artifacts

When a chart is compiled through Flint, preserve a reproducible set beside the canonical lesson:

```text
chart.data.json
chart.flint.json
chart.svg
chart.render.json
lesson.md
lesson.html
```

The render manifest records the pinned Flint/backend versions, command or API, data/spec/output SHA-256 values, warnings, verification time, and known limitations. Prefer build-time SVG; keep interactive preview tooling out of the essential delivery path.

Embed the chart in a semantic `<figure>` with a useful caption, short alternative, and nearby complete data table or extended description. Verify units, sample size, uncertainty, missingness, axes, domains, baselines, category retention, and color-independent meaning.

Fail closed on unsupported templates, render failure, or unresolved warnings about filtering, truncation, semantics, or backend coverage. If Flint is unavailable, preserve the lesson with a semantic table or verified native SVG rather than introducing a mandatory network dependency.

Read [FLINT-CHARTS.md](./FLINT-CHARTS.md) for the authoring and accessibility contract.

## Build and parity

The renderer must:

- parse the project’s declared Markdown dialect consistently;
- slug headings deterministically and deduplicate anchors;
- escape raw untrusted HTML unless the content policy explicitly allows reviewed HTML;
- preserve code exactly;
- sanitize or block dangerous URLs and event attributes;
- resolve relative links from the source document;
- embed or localize required assets for offline use;
- record renderer/template versions;
- produce a source hash from the exact Markdown bytes.

Use the bundled renderer for the default dialect. A custom renderer is justified only when a required learner action cannot be expressed with the default contract; record that decision, preserve a static fallback, and test the renderer independently before delivery.

The validator must check:

- every `.md` has same-basename `.html`;
- every HTML companion names the source and matching SHA-256;
- no placeholder/TODO text remains in production artifacts;
- local links and anchors resolve;
- required metadata and landmarks exist;
- heading levels do not skip unexpectedly;
- duplicate IDs are absent;
- external dependencies are declared and intentional;
- Flint-derived assets, when present, have local data/spec/output files, matching recorded hashes, reviewed warnings, and a table/text alternative;
- learner-state JSON/JSONL remains separate from lesson content.

When an HTML renderer cannot safely preserve a construct, fail with a clear diagnostic. Do not silently omit it.

## Acceptance checklist

### Content

- [ ] One observable outcome.
- [ ] Correct, versioned, nearby sources.
- [ ] Attempt before answer when retrieval is intended.
- [ ] Explained worked example where useful.
- [ ] Progressive hints.
- [ ] Specific feedback and next attempt.
- [ ] Unseen transfer task.
- [ ] Honest evidence/uncertainty statement.
- [ ] Next retrieval tied to the retention horizon.

### HTML

- [ ] Markdown is canonical and hash matches.
- [ ] Semantic structure and stable anchors.
- [ ] Keyboard, focus, zoom/reflow, and reduced motion pass.
- [ ] Print and no-script paths remain useful.
- [ ] Visuals have editable sources, alternatives, and provenance.
- [ ] No answer leakage from HTML, CSS, scripts, media, or accessibility text.
- [ ] No mandatory external network dependency.

### Delivery

- [ ] Regenerate all companions.
- [ ] Run `node <skill-dir>/scripts/render_markdown.mjs --check <source.md>` for each delivered lesson/reference.
- [ ] Run the workspace validator.
- [ ] Inspect representative pages in a real browser.
- [ ] Report what was tested and any known limitation.
