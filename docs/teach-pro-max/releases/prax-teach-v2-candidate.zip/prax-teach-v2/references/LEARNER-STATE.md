# Learner-state contract

## Contents

1. [Principles](#principles)
2. [Workspace files](#workspace-files)
3. [Observation schema](#observation-schema)
4. [Concept state](#concept-state)
5. [Misconceptions](#misconceptions)
6. [Review scheduling](#review-scheduling)
7. [Consent and correction](#consent-and-correction)
8. [Resume and migration](#resume-and-migration)
9. [Validation invariants](#validation-invariants)

## Principles

- Store raw observations separately from interpreted state.
- Link every inference to evidence IDs.
- Keep learner-authored content distinct from agent-authored inference.
- Represent uncertainty and contradictory evidence.
- Track concept dimensions rather than a personality or global ability label.
- Let the learner inspect, correct, retest, export, and delete state.
- Minimize data and never persist without explicit consent.
- Version content, items, models, prompts, and sources that affect interpretation.

## Workspace files

```text
state/
├── learner.json
├── concepts.json
├── misconceptions.json
├── reviews.jsonl
└── sessions.jsonl
```

### `learner.json`

Store only learner-approved settings:

```json
{
  "schema_version": "1",
  "learner_id": "local-pseudonym",
  "consent": {
    "persistent_state": true,
    "granted_at": "2026-08-03T12:00:00Z",
    "scope": ["goal", "practice_evidence", "reviews", "access_preferences"]
  },
  "goal": {
    "statement": "Choose and justify database indexes for production queries",
    "target_performance": "Solve unseen schema and workload cases without hints",
    "retention_horizon_days": 30
  },
  "preferences": {
    "response_pace": "concise",
    "reduced_motion": true,
    "response_modes": ["text", "code"]
  }
}
```

Do not store diagnoses, protected traits, health data, or inferred “learning styles.” Access preferences are functional choices, not ability labels.

### `sessions.jsonl`

Append one observation or session event per line. Never edit history silently. Corrections are new events referencing the corrected event.

### `concepts.json`

Store the current derived view and evidence links. It may be rebuilt from observations.

### `misconceptions.json`

Store specific incorrect rules or mental models only when supported by learner reasoning. Do not equate one wrong answer with a stable misconception.

### `reviews.jsonl`

Store scheduler inputs, outputs, performance-derived ratings, overrides, and due-item events.

## Observation schema

Record at minimum:

```json
{
  "schema_version": "1",
  "event_id": "evt-unique",
  "session_id": "session-unique",
  "timestamp": "2026-08-03T12:34:56Z",
  "content_id": "lesson-index-prefixes",
  "content_version": "sha256:...",
  "objective_id": "obj-index-choice",
  "concept_id": "composite-index-prefix",
  "item_id": "item-transfer-03",
  "item_variant": "v1",
  "response_ref": "inline-or-artifact-reference",
  "rubric": {
    "score": 0.75,
    "dimensions": {
      "recall": null,
      "explanation": 1,
      "application": 0.5,
      "discrimination": 1,
      "transfer": 0.5
    }
  },
  "learner_confidence": 0.8,
  "latency_ms": null,
  "hint_level": 2,
  "feedback_type": "process-and-next-action",
  "attempt_number": 2,
  "source_provenance": ["source-id"],
  "model_and_prompt_version": "declared-version",
  "agent_inference": {
    "summary": "Understands prefix matching; transfer remains uncertain",
    "certainty": 0.62
  },
  "learner_authored": null
}
```

Use `null` rather than invented precision. Do not record keystroke-level or response-time data unless it serves an explicit, consented purpose.

## Concept state

Represent each dimension separately:

```json
{
  "concept_id": "composite-index-prefix",
  "prerequisites": ["btree-order", "query-predicate-types"],
  "dimensions": {
    "recognition": {"estimate": 0.9, "evidence_ids": ["evt-1"]},
    "recall": {"estimate": 0.55, "evidence_ids": ["evt-2"]},
    "explanation": {"estimate": 0.7, "evidence_ids": ["evt-3"]},
    "application": {"estimate": 0.6, "evidence_ids": ["evt-4"]},
    "discrimination": {"estimate": 0.65, "evidence_ids": ["evt-5"]},
    "transfer": {"estimate": null, "evidence_ids": []}
  },
  "status": "developing",
  "status_reason": "No unassisted transfer evidence",
  "contradictions": [],
  "last_updated": "2026-08-03T12:40:00Z"
}
```

### Status vocabulary

- `unobserved`: no usable evidence;
- `emerging`: partial or highly scaffolded evidence;
- `developing`: some independent evidence but incomplete dimensions or contradictions;
- `provisional`: multiple independent demonstrations without later-session confirmation;
- `durable`: later-session unassisted retrieval plus application/discrimination/transfer;
- `stale`: evidence is too old or source/content changes invalidate it.

Status is an explainable convenience, not a psychometric fact.

### Update rules

- Weight unassisted evidence more than heavily hinted evidence.
- Weight transfer and discrimination more than exact-repeat recognition for flexible mastery.
- Preserve negative and contradictory evidence.
- Decay certainty rather than rewriting history.
- Recompute when the rubric, content, item, model, or source version changes materially.
- Never treat a model-generated estimate as ground truth.

Begin with transparent heuristic aggregation. Add BKT or another interpretable model only after calibration and held-out evaluation. Predictive accuracy alone does not show that model-driven adaptation improves learning.

## Misconceptions

Use this shape:

```json
{
  "misconception_id": "mis-prefix-any-order",
  "concept_id": "composite-index-prefix",
  "claim": "Column order does not matter in a composite index",
  "state": "suspected",
  "evidence_ids": ["evt-7"],
  "learner_confirmed": false,
  "repair_attempts": [],
  "last_tested": null
}
```

Lifecycle:

1. `suspected` after one reasoning trace;
2. `supported` after recurrence or a discriminating probe;
3. `repairing` after targeted explanation/practice;
4. `resolved` only after an unassisted confusable or transfer case;
5. `recurred` if it reappears later.

Let the learner reject an inaccurate misconception record.

## Review scheduling

Keep item scheduling separate from concept state.

Scheduler input:

- item ID/version;
- actual correctness or rubric result;
- response independence and hint level;
- prior schedule state;
- desired retention horizon;
- learner override.

Scheduler output:

- due time;
- target retention probability if the scheduler exposes one;
- chosen performance rating and its derivation;
- reason;
- algorithm/version.

Never turn “the learner seemed comfortable” into a scheduler rating. Use a tested FSRS implementation when available; otherwise use an explicit temporary policy and label it heuristic.

## Consent and correction

Before state creation, resolve the exact workspace and obtain consent. Show material updates at session close.

Support these operations:

- show my learner model;
- explain why a concept has this status;
- correct this inference;
- mark this note as learner-authored;
- retest this concept;
- export my data;
- delete this session, concept inference, or all state;
- disable persistence or review scheduling.

Deletion must be real and scoped. If backups or external exports exist, explain their retention separately.

## Resume and migration

On resume:

1. Resolve the intended workspace; do not guess among similar paths.
2. Validate schema versions and JSON/JSONL parseability.
3. Read consent scope before other state.
4. Summarize the goal, due reviews, recent evidence, uncertainty, and conflicts.
5. Start with a due retrieval or current-goal check, not a long recap.
6. Update only after new observable evidence.

On schema migration:

- back up the exact state files;
- migrate deterministically with a versioned script;
- preserve event IDs and provenance;
- emit a migration report;
- validate invariants;
- let the learner inspect changes.

Do not silently reconstruct missing history from model memory.

## Validation invariants

- Every concept evidence ID exists in `sessions.jsonl`.
- Every inferred status has a non-empty reason.
- `durable` includes later-session, unassisted evidence.
- Learner-authored and agent-inferred fields never share the same storage slot.
- Every misconception links to an observation of reasoning, not only a wrong choice.
- Every review decision records algorithm/version and performance-derived input.
- No durable state exists without consent metadata.
- Timestamps, IDs, and schema versions are valid and unique where required.
- Source/content version changes can flag dependent evidence as stale.
