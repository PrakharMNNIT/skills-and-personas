# Evaluation contract

## Contents

1. [Separate the claims](#separate-the-claims)
2. [Agent-level evaluation](#agent-level-evaluation)
3. [Behavioral fixtures](#behavioral-fixtures)
4. [Optimizer evaluation](#optimizer-evaluation)
5. [Artifact and HTML checks](#artifact-and-html-checks)
6. [Learner-outcome evaluation](#learner-outcome-evaluation)
7. [Release gates](#release-gates)

## Separate the claims

| Claim | Evidence |
|---|---|
| Skill is valid | Package/schema/script validation |
| Skill triggers correctly | Positive, negative, and boundary cases |
| Tutor follows policy | Observable behavior and forbidden-outcome graders |
| Artifact is good | Correctness, usability, accessibility, provenance |
| Learner improved | Randomized learner outcomes |
| Learning endured and transferred | Delayed unseen retention and novel transfer |

Never describe artifact preference or evaluator score as a learning gain.

## Agent-level evaluation

Use a truly skill-absent control. Merely omitting the skill name from the prompt is not absence if the target files or excerpts remain discoverable.

Hold constant:

- exact model and sampling settings;
- system/configuration fingerprint;
- all non-target skills and tools;
- fixture bytes and starting state;
- network, permissions, dependencies, timeout, and token budget;
- hidden graders;
- fresh context and workspace.

Fingerprint the whole target skill. Randomize run order. Keep outputs outside future agents’ visible workspaces.

For the current evaluation architecture, run:

1. normal agent vs frozen `teach`;
2. normal agent vs fingerprinted `prax-teach-v2`.

Use three trials per arm as a smoke stage and predeclare a ceiling of five. Expand only inconclusive cases without changing substantive settings. This is an engineering procedure, not a powered human-study design.

## Behavioral fixtures

Include positive, negative, and boundary cases across:

- `quick`, `lesson`, and `course`;
- no visual, static, interactive, motion, and ambiguous visual need;
- novice, expert, high-confidence error, low-confidence correct response;
- retrieval, hinting, misconception repair, feedback, teach-back, and transfer;
- no persistence consent, accepted persistence, resume, stale evidence, correction, export, deletion;
- reduced motion, keyboard-only, no JavaScript, screen-reader, and narrow viewport;
- explicit **Answer now** and frustration;
- missing, contradictory, unstable, and high-stakes sources.

Score desired behavior and forbidden behavior separately.

The bundled `references/eval-cases.json` and `evals/evals.json` files are public development material because the target package can discover them. Never call those cases held-out. Keep selection/test prompts, answers, rubrics, grader instructions, and exact hard-gate fixtures outside every target workspace.

### Hard forbidden outcomes

- premature or interface-level answer leakage;
- continued Socratic interrogation after **Answer now**;
- fabricated fact, citation, observation, learner history, or scheduler rating;
- silent persistence or sensitive-trait inference;
- false mastery from one response, fluency, confidence, completion, or activity;
- essential information lost under keyboard, no-script, print, zoom, or reduced motion;
- visual or interaction chosen only for decoration;
- hidden grader content exposed to the teaching agent.

Any critical instance blocks release regardless of the average score.

## Optimizer evaluation

An instruction optimizer such as [SkillOpt](https://github.com/microsoft/SkillOpt) may propose a stronger `SKILL.md`, but it does not change the evidence ladder.

Use four isolated banks:

- public train/development cases for reflection;
- hidden selection cases for repeated candidate gating;
- an untouched hidden test opened once after freezing the candidate;
- an out-of-distribution bank for a different model, harness, topic, and surface form.

For each optimizer rollout, clone the complete package, replace only the cloned `SKILL.md`, and leave the references/scripts frozen. Fingerprint the target, optimizer, configuration, permissions, dependencies, splits, graders, and budgets.

Apply deterministic critical checks before any soft judge. Reject a candidate for any answer leakage, silent persistence, fabricated source or state, false mastery, inaccessible essential content, destructive behavior, or hidden-grader exposure. These failures are non-compensatory; a higher scalar mean cannot offset them.

Because rollouts and judges are nondeterministic, require repeated paired trials and an improvement larger than measured noise. Stage the optimizer artifact for human diff review, regenerate the full package, and rerun forward tests. Never auto-adopt.

Read [SKILLOPT-OPTIMIZATION.md](./SKILLOPT-OPTIMIZATION.md) for the complete boundary and pilot policy.

## Artifact and HTML checks

For every Markdown artifact:

- same-basename HTML exists;
- recorded source SHA-256 matches;
- title, headings, links, code, tables, and citations remain present;
- local links and anchors resolve;
- semantic landmarks, skip link, language, viewport, and focus styles exist;
- interactions are keyboard-operable and have static/no-script fallbacks;
- reduced-motion and print paths preserve information;
- no mandatory external request is introduced;
- retrieval answers are not exposed in pre-attempt HTML, metadata, CSS, scripts, or alternatives.

For a Flint-derived chart, additionally require a pinned version, prepared source data, editable semantic spec, render manifest, recorded warnings, reproducible hashes, exact axes/units/domains, and a complete table or extended text equivalent. An unresolved filtering, truncation, semantic-type, or backend warning blocks delivery.

Run automated checks and perform manual browser/accessibility review.

## Learner-outcome evaluation

Use a user-level, parallel randomized design when making a causal product claim:

1. active-control agent without a teaching skill;
2. frozen `teach`;
3. `prax-teach-v2`.

Do not use crossover as the main design because acquired knowledge carries into later conditions.

### Predeclare with evidence-centered design

- **competency claim:** the independent performance expected;
- **evidence:** observable behavior that supports it;
- **task:** unseen item that elicits the evidence without copying lesson wording.

Reference [Evidence-Centered Design](https://www.ets.org/research/policy_research_reports/publications/report/2003/hsgs.html), the [Standards for Educational and Psychological Testing](https://www.testingstandards.net/), and applicable [What Works Clearinghouse standards](https://ies.ed.gov/ncee/wwc/Handbooks).

### Primary outcomes

- delayed retention on unseen parallel items;
- novel transfer blind-scored against a rubric.

### Secondary outcomes

- immediate comprehension;
- time/attempts to durable evidence;
- misconception recurrence;
- confidence calibration;
- hint dependence;
- voluntary continuation.

### Guardrails

- dropout, frustration, and session burden;
- tutor factual errors;
- false-mastered rate;
- accessibility failures;
- subgroup outcome/calibration gaps;
- learner-model corrections;
- latency, token, and monetary cost.

Use a delay aligned to the real retention goal—commonly 7–14 days plus an optional 30-day check. Keep assessment items hidden from lesson generation. Use parallel forms, blind graders, intention-to-treat analysis, attrition reporting, effect sizes, confidence intervals, and pilot-informed power.

## Release gates

Ship only when:

- structure, scripts, state invariants, and artifact parity pass;
- trigger behavior stays within predeclared bounds in every critical stratum;
- no critical forbidden outcome appears;
- optimizer proposals pass hidden non-compensatory guardrails, repeated improvement beyond measured noise, human diff review, and untouched test evaluation;
- quick/no-visual cases are non-inferior and use less or equal ceremony;
- visual-benefit cases improve representation appropriateness without accessibility regressions;
- course state survives resume, is correctable, and drives relevant review;
- claims are limited to the level of evidence actually collected.

Treat existing 10% lift and 5% regression/over-trigger values as provisional agent-evaluation defaults only. Define metric-specific educational thresholds and power before learner data collection.

Until delayed learner outcomes exist, use this claim:

> The candidate implements a more explicit, inspectable, and testable tutoring policy.

Do not claim it teaches better yet.
