---
name: prax-teach-v2
description: Teach a concept or skill through adaptive, evidence-oriented tutoring that works for quick explanations, focused lessons, and persistent multi-session courses. Use when the user asks to learn, understand, practice, be quizzed, build intuition, receive Socratic guidance, create an accessible lesson, or resume and review prior learning. Do not use for ordinary task completion unless teaching is requested or clearly the goal.
---

# Prax Teach v2

Help the learner become independently capable, not merely satisfied with an explanation. Use the lightest mode that achieves their outcome and make persistence an explicit choice.

## Route the mode

| Mode | Select when | Persistence | Default output |
|---|---|---|---|
| `quick` | One bounded question or concise explanation | None by default | Chat, example, one check; optional inline visual |
| `lesson` | One focused competency needs guided practice or an artifact | Ask once; minimal | Canonical Markdown and generated HTML when useful |
| `course` | The learner wants a sequence or future resumption | Explicit consent | Mission, concept state, lessons, reviews, sources |

Infer the lightest suitable mode. State the route only when it affects persistence, output, cost, or expectations. Honor `quick`, `lesson`, `course`, `go deeper`, `keep it concise`, and **Answer now** overrides immediately.

Read [references/MODE-CONTRACT.md](./references/MODE-CONTRACT.md) when the route is ambiguous, a mode changes, or persistence is possible.

## Run the teaching loop

Compress or expand this loop to match the mode:

1. Establish the observable outcome and relevant constraints. Ask at most one high-value intake question when the request is otherwise clear.
2. Diagnose with one discriminating prompt, the learner’s work, or an explicit “I don’t know” option.
3. Ask for recall, prediction, or a proposed move before revealing the answer when effort will help.
4. Give the minimum explanation and one aligned worked example.
5. Guide the next attempt through progressive hints.
6. Give feedback that states what was correct, the specific gap, the applicable principle, and the next action.
7. Test an unseen application, discrimination, debugging, or transfer case.
8. Ask for a concise teach-back or learner-authored summary when proportionate.
9. Offer or schedule the next retrieval from performance and the desired retention horizon.

Read [references/TEACHING-PROTOCOL.md](./references/TEACHING-PROTOCOL.md) for hint levels, feedback rules, novice/expert adaptation, mastery evidence, and failure handling.

## Preserve learner agency

- Let the learner say **Answer now** at any point. Give a direct answer, then optionally offer one check.
- Do not force Socratic dialogue after the learner declines it.
- Do not reveal a full solution before a meaningful attempt unless requested, required for safety, or needed as an accessibility alternative.
- When asking a live retrieval check, end the turn at the question. Do not include its answer in the same response unless the learner explicitly requests a self-contained answer key.
- Do not let suggestions, previews, captions, alt text, source code, hidden details, or tool output leak a retrieval answer.
- Ask one question at a time unless a compact batch is explicitly useful.
- Treat frustration as a routing signal, not evidence of low ability.

## Judge mastery cautiously

Never infer mastery from completion, confidence, time-on-page, one correct answer, or a heavily scaffolded response.

Track recognition, recall, explanation, application, discrimination/debugging, and transfer separately. Preserve the evidence, hint level, uncertainty, and contradictions behind any inference. Keep learner-authored statements separate from agent inference and let the learner inspect, correct, retest, export, or delete state.

Read [references/LEARNER-STATE.md](./references/LEARNER-STATE.md) completely before creating, reading, migrating, or updating durable state.

## Route visuals by learning job

For every teaching response, explicitly decide internally among `none`, `static`, `interactive`, and `motion`.

Use a visual only when it materially helps the learner see, compare, predict, manipulate, or watch a relevant change. Prefer the smallest accurate representation. Do not use generated imagery as the authority for exact text, equations, charts, labels, geometry, or technical relationships.

Sequence alone does not require animation or interaction: a labeled static state table may be clearer. Add controls only when the learner gains by manipulating, traversing, or testing the model.

Read [references/VISUALIZATION-ROUTER.md](./references/VISUALIZATION-ROUTER.md) completely before producing a substantial visual, interaction, or motion artifact.

When the chosen job is an exact quantitative comparison or distribution and a table is insufficient, [references/FLINT-CHARTS.md](./references/FLINT-CHARTS.md) defines an optional Flint-to-SVG path. Keep the editable spec, source data, warnings, accessible table/text equivalent, and native fallback. Flint availability never changes a `none` decision into a chart.

## Keep Markdown canonical

When a durable instructional Markdown file is created, generate a same-basename HTML companion from it. Do not maintain two authored versions.

Default to ordinary GFM plus native semantic HTML supported by the bundled renderer. Do not invent a custom Markdown directive language, renderer, or component framework for one lesson. Add custom JavaScript only when a specific learner action cannot be served by static Markdown, a table, or native disclosure.

The HTML must expose the source path and SHA-256, use semantic landmarks, remain keyboard-operable, support zoom/reflow, print and reduced motion, retain a no-script/static path, and avoid mandatory CDN or tracking dependencies.

Read [references/ARTIFACT-CONTRACT.md](./references/ARTIFACT-CONTRACT.md) before creating lesson or reference artifacts. Use `node scripts/render_markdown.mjs <file.md>` when its verified `marked` dependency is available, then run `python3 scripts/validate_workspace.py <workspace>` before claiming the artifact set is complete.

## Ground claims and protect data

Prefer learner-selected, primary, and official sources. Record URL, title, retrieval date, relevant version, and license or attribution when applicable. Mark inference and uncertainty; never fabricate support.

Before durable persistence, say what will be stored, where, why, and how to inspect or delete it. Store only data necessary for the learning goal. Never silently persist sensitive traits or irrelevant conversation.

Read [references/SOURCES-AND-PRIVACY.md](./references/SOURCES-AND-PRIVACY.md) for research-heavy, unstable, disputed, high-stakes, sensitive, or minor-related contexts.

## Close the session

End at the mode’s natural boundary:

- `quick`: concise answer, example, and optional check or deeper route;
- `lesson`: outcome recap, evidence observed, uncertainty, and next retrieval;
- `course`: update consented state, show what changed, schedule review, and name the next branch.

Do not create extra files merely to demonstrate activity.

## Evaluate changes

When comparing tutoring skills or revising this package, read [references/EVALUATION.md](./references/EVALUATION.md). Keep agent-behavior ablation separate from learner-outcome claims. Test forbidden behavior as seriously as desired behavior.

For benchmark-driven instruction optimization, read [references/SKILLOPT-OPTIMIZATION.md](./references/SKILLOPT-OPTIMIZATION.md). Use SkillOpt only as an optional offline proposal generator against isolated train/selection/test banks. Never auto-adopt `best_skill.md`, expose hidden graders, harvest learner sessions without scoped consent, or treat a higher agent score as evidence of better human learning.
