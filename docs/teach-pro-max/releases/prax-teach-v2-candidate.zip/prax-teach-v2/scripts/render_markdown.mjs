#!/usr/bin/env node

import { createHash } from 'node:crypto';
import { readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

function usage() {
  console.error('Usage: render_markdown.mjs [--check] <source.md> [output.html]');
  process.exit(2);
}

const args = process.argv.slice(2);
const checkOnly = args[0] === '--check';
if (checkOnly) args.shift();
if (args.length < 1 || args.length > 2 || !args[0].endsWith('.md')) usage();

const sourcePath = path.resolve(args[0]);
const outputPath = path.resolve(args[1] || sourcePath.replace(/\.md$/, '.html'));

async function loadMarked() {
  try {
    return (await import('marked')).marked;
  } catch {
    const candidates = [
      process.env.PRAX_MARKED_PATH,
      '/Users/prax/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/marked/lib/marked.esm.js',
    ].filter(Boolean);
    for (const candidate of candidates) {
      try {
        return (await import(pathToFileURL(candidate).href)).marked;
      } catch {
        // Continue to the next explicitly verified renderer path.
      }
    }
  }
  throw new Error('marked is required at generation time. Install it or set PRAX_MARKED_PATH.');
}

function escapeHtml(value) {
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');
}

function stripFrontmatter(markdown) {
  if (!markdown.startsWith('---\n')) return markdown;
  const end = markdown.indexOf('\n---\n', 4);
  return end === -1 ? markdown : markdown.slice(end + 5);
}

function stripTags(value) {
  return value.replace(/<[^>]+>/g, '').replace(/&[^;]+;/g, ' ').trim();
}

function slug(value) {
  return value.normalize('NFKD').toLowerCase()
    .replace(/[^\p{Letter}\p{Number}\s-]/gu, '')
    .trim().replace(/[\s_-]+/g, '-') || 'section';
}

function enrich(raw) {
  const seen = new Map();
  let html = raw.replace(/<h([1-6])>([\s\S]*?)<\/h\1>/g, (all, level, inner) => {
    const base = slug(stripTags(inner));
    const count = seen.get(base) || 0;
    seen.set(base, count + 1);
    const id = count ? `${base}-${count + 1}` : base;
    return `<h${level} id="${escapeHtml(id)}">${inner}</h${level}>`;
  });
  html = html
    .replace(/href="([^"#?]+)\.md(#[^"]*)?"/g, 'href="$1.html$2"')
    .replace(/\b(href|src)="([^"]*)"/g, (all, attribute, value) => `${attribute}="${value.replace(/&(?!#\d+;|#x[0-9a-f]+;|[a-z][a-z0-9]+;)/gi, '&amp;')}"`)
    .replaceAll('<table>', '<div class="table-wrap" tabindex="0" role="region" aria-label="Scrollable table"><table>')
    .replaceAll('</table>', '</table></div>');
  return html;
}

const source = await readFile(sourcePath);
const hash = createHash('sha256').update(source).digest('hex');

if (checkOnly) {
  let html;
  try {
    html = await readFile(outputPath, 'utf8');
  } catch {
    console.error(`Missing HTML companion: ${outputPath}`);
    process.exit(1);
  }
  const match = html.match(/<meta name="source-sha256" content="([0-9a-f]{64})">/i);
  if (!match || match[1] !== hash) {
    console.error(`Stale or missing source hash: ${outputPath}`);
    process.exit(1);
  }
  console.log(`Fresh: ${outputPath}`);
  process.exit(0);
}

const markdown = stripFrontmatter(source.toString('utf8'));
const titleMatch = markdown.match(/^#\s+(.+)$/m);
const title = titleMatch ? titleMatch[1].replace(/[`*_]/g, '').trim() : path.basename(sourcePath, '.md');
const marked = await loadMarked();
marked.setOptions({ gfm: true, breaks: false });
const content = enrich(await marked.parse(markdown));
const generatedAt = process.env.SOURCE_DATE_EPOCH || new Date().toISOString();
const sourceName = path.basename(sourcePath);

const html = `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="color-scheme" content="light dark">
  <meta name="source-path" content="${escapeHtml(sourceName)}">
  <meta name="source-sha256" content="${hash}">
  <meta name="generated-at" content="${escapeHtml(generatedAt)}">
  <title>${escapeHtml(title)}</title>
  <style>
    :root { color-scheme: light; --paper:#f7f3ea; --ink:#172235; --muted:#5d6674; --accent:#8f3b20; --teal:#176b69; --line:#d7cbb8; --surface:#fffdf8; --code:#1c2837; --code-ink:#f4f1ea; }
    @media (prefers-color-scheme: dark) { :root { color-scheme: dark; --paper:#111923; --ink:#edf2f5; --muted:#b4bdc8; --accent:#f19a72; --teal:#72cbc5; --line:#344355; --surface:#182331; --code:#09111a; --code-ink:#edf2f5; } }
    * { box-sizing:border-box; }
    html { scroll-behavior:smooth; }
    body { margin:0; background:var(--paper); color:var(--ink); font:17px/1.68 ui-sans-serif,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif; }
    a { color:var(--accent); text-underline-offset:.16em; }
    a:focus-visible, [tabindex="0"]:focus-visible, summary:focus-visible { outline:3px solid var(--teal); outline-offset:3px; }
    .skip-link { position:fixed; left:1rem; top:.7rem; transform:translateY(-180%); z-index:10; padding:.6rem .85rem; border-radius:.4rem; background:var(--ink); color:var(--paper); }
    .skip-link:focus { transform:translateY(0); }
    header { border-bottom:1px solid var(--line); background:var(--surface); }
    header div, main, footer { width:min(840px, calc(100% - 2rem)); margin-inline:auto; }
    header div { display:flex; justify-content:space-between; gap:1rem; padding:1rem 0; }
    header strong { color:var(--teal); letter-spacing:.04em; }
    main { padding:clamp(2.4rem,7vw,5rem) 0; }
    h1,h2,h3,h4 { font-family:ui-serif,Georgia,Cambria,serif; line-height:1.15; text-wrap:balance; scroll-margin-top:2rem; }
    h1 { max-width:16ch; margin:0 0 1.5rem; font-size:clamp(2.5rem,8vw,4.8rem); letter-spacing:-.04em; }
    h2 { margin:3.2rem 0 1rem; font-size:clamp(1.7rem,4vw,2.4rem); }
    h3 { margin:2.1rem 0 .6rem; font-size:1.35rem; }
    p,li { max-width:72ch; }
    blockquote { margin:1.4rem 0; padding:.75rem 1.1rem; border-left:.3rem solid var(--accent); background:var(--surface); }
    code { padding:.1em .3em; border:1px solid var(--line); border-radius:.3rem; font: .88em/1.4 ui-monospace,SFMono-Regular,Menlo,monospace; }
    pre { overflow:auto; padding:1rem 1.1rem; border-radius:.65rem; background:var(--code); color:var(--code-ink); }
    pre code { padding:0; border:0; color:inherit; }
    .table-wrap { overflow:auto; margin:1.4rem 0; border:1px solid var(--line); border-radius:.65rem; }
    table { width:100%; border-collapse:collapse; background:var(--surface); font-size:.92rem; }
    th,td { padding:.72rem .8rem; border-bottom:1px solid var(--line); text-align:left; vertical-align:top; }
    th { font-size:.78rem; text-transform:uppercase; letter-spacing:.03em; }
    details { margin:1rem 0; padding:.75rem 1rem; border:1px solid var(--line); border-radius:.6rem; background:var(--surface); }
    summary { cursor:pointer; font-weight:700; }
    footer { padding:1.2rem 0 2.5rem; border-top:1px solid var(--line); color:var(--muted); font-size:.78rem; overflow-wrap:anywhere; }
    @media (prefers-reduced-motion:reduce) { html { scroll-behavior:auto; } *,*::before,*::after { animation-duration:.01ms!important; transition-duration:.01ms!important; } }
    @media print { :root { --paper:#fff; --ink:#000; --surface:#fff; --line:#aaa; } header,.skip-link { display:none; } body { font-size:10.5pt; } main,footer { width:100%; } h1 { max-width:none; font-size:28pt; } pre,table,blockquote { break-inside:avoid; } a[href^="http"]::after { content:" (" attr(href) ")"; font-size:8pt; } }
  </style>
</head>
<body>
  <a class="skip-link" href="#main-content">Skip to content</a>
  <header><div><strong>Prax Teach lesson</strong><a href="./${escapeHtml(sourceName)}">Markdown source</a></div></header>
  <main id="main-content">${content}</main>
  <footer>
    Canonical source: <a href="./${escapeHtml(sourceName)}">${escapeHtml(sourceName)}</a><br>
    SHA-256: <code>${hash}</code><br>
    Generated: ${escapeHtml(generatedAt)}
  </footer>
</body>
</html>`;

await writeFile(outputPath, html, 'utf8');
console.log(`Rendered ${sourcePath} -> ${outputPath}`);
