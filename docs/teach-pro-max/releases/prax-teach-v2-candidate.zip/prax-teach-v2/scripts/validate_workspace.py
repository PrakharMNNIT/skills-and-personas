#!/usr/bin/env python3
"""Validate Markdown/HTML parity and core Prax Teach workspace invariants."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import unquote, urlparse


SOURCE_HASH_RE = re.compile(
    r'<meta\s+name=["\']source-sha256["\']\s+content=["\']([0-9a-f]{64})["\']',
    re.IGNORECASE,
)
SOURCE_PATH_RE = re.compile(
    r'<meta\s+name=["\']source-path["\']\s+content=["\']([^"\']+)["\']',
    re.IGNORECASE,
)


class PageParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.tags: list[str] = []
        self.ids: list[str] = []
        self.hrefs: list[str] = []
        self.external_assets: list[str] = []
        self.heading_levels: list[int] = []
        self.has_lang = False
        self.has_charset = False
        self.has_viewport = False
        self.has_skip_link = False
        self.has_title = False
        self._in_title = False
        self._title_text: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        self.tags.append(tag)
        values = {key: value or "" for key, value in attrs}
        if tag == "html" and values.get("lang", "").strip():
            self.has_lang = True
        if tag == "meta" and "charset" in values:
            self.has_charset = True
        if tag == "meta" and values.get("name", "").lower() == "viewport":
            self.has_viewport = True
        if tag == "title":
            self._in_title = True
        if tag == "a":
            href = values.get("href", "")
            if href:
                self.hrefs.append(href)
            classes = set(values.get("class", "").split())
            if "skip-link" in classes and href.startswith("#"):
                self.has_skip_link = True
        if "id" in values:
            self.ids.append(values["id"])
        if len(tag) == 2 and tag.startswith("h") and tag[1].isdigit():
            self.heading_levels.append(int(tag[1]))
        if tag in {"script", "img", "video", "audio", "source", "iframe"}:
            src = values.get("src", "")
            if src.startswith(("http://", "https://", "//")):
                self.external_assets.append(src)
        if tag == "link" and values.get("rel", "").lower() == "stylesheet":
            href = values.get("href", "")
            if href.startswith(("http://", "https://", "//")):
                self.external_assets.append(href)

    def handle_endtag(self, tag: str) -> None:
        if tag == "title":
            self._in_title = False
            self.has_title = bool("".join(self._title_text).strip())

    def handle_data(self, data: str) -> None:
        if self._in_title:
            self._title_text.append(data)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check_heading_order(levels: list[int]) -> list[str]:
    errors: list[str] = []
    if levels.count(1) != 1:
        errors.append(f"expected exactly one h1, found {levels.count(1)}")
    previous = 0
    for level in levels:
        if previous and level > previous + 1:
            errors.append(f"heading level jumps from h{previous} to h{level}")
        previous = level
    return errors


def resolve_local_link(page: Path, href: str) -> tuple[Path | None, str | None]:
    parsed = urlparse(href)
    if parsed.scheme or parsed.netloc or href.startswith(("mailto:", "tel:")):
        return None, None
    if href.startswith("#"):
        return page, unquote(parsed.fragment)
    target_text = unquote(parsed.path)
    if not target_text:
        return page, unquote(parsed.fragment) if parsed.fragment else None
    target = (page.parent / target_text).resolve()
    return target, unquote(parsed.fragment) if parsed.fragment else None


def parse_page(path: Path) -> PageParser:
    parser = PageParser()
    parser.feed(path.read_text(encoding="utf-8"))
    return parser


def validate_html_pair(markdown: Path, root: Path) -> list[str]:
    errors: list[str] = []
    html = markdown.with_suffix(".html")
    rel = markdown.relative_to(root)
    if not html.exists():
        return [f"{rel}: missing companion {html.name}"]

    text = html.read_text(encoding="utf-8")
    hash_match = SOURCE_HASH_RE.search(text)
    if not hash_match:
        errors.append(f"{html.relative_to(root)}: missing source-sha256 meta")
    elif hash_match.group(1) != sha256(markdown):
        errors.append(f"{html.relative_to(root)}: stale source hash")

    path_match = SOURCE_PATH_RE.search(text)
    expected_source = markdown.name
    if not path_match:
        errors.append(f"{html.relative_to(root)}: missing source-path meta")
    elif Path(path_match.group(1)).name != expected_source:
        errors.append(
            f"{html.relative_to(root)}: source path points to {path_match.group(1)!r}, "
            f"expected {expected_source!r}"
        )

    parser = parse_page(html)
    required = {"header", "main", "footer"}
    missing = required.difference(parser.tags)
    if missing:
        errors.append(f"{html.relative_to(root)}: missing landmarks {sorted(missing)}")
    if not parser.has_lang:
        errors.append(f"{html.relative_to(root)}: html lang missing")
    if not parser.has_charset:
        errors.append(f"{html.relative_to(root)}: charset missing")
    if not parser.has_viewport:
        errors.append(f"{html.relative_to(root)}: viewport missing")
    if not parser.has_title:
        errors.append(f"{html.relative_to(root)}: non-empty title missing")
    if not parser.has_skip_link:
        errors.append(f"{html.relative_to(root)}: skip link missing")
    if len(parser.ids) != len(set(parser.ids)):
        errors.append(f"{html.relative_to(root)}: duplicate IDs")
    for problem in check_heading_order(parser.heading_levels):
        errors.append(f"{html.relative_to(root)}: {problem}")
    if parser.external_assets:
        errors.append(
            f"{html.relative_to(root)}: mandatory external assets: {parser.external_assets}"
        )
    return errors


def validate_local_links(html_files: list[Path], root: Path) -> list[str]:
    errors: list[str] = []
    parsed_pages = {path.resolve(): parse_page(path) for path in html_files}
    for page in html_files:
        parser = parsed_pages[page.resolve()]
        for href in parser.hrefs:
            target, fragment = resolve_local_link(page, href)
            if target is None:
                continue
            if not target.exists():
                errors.append(f"{page.relative_to(root)}: broken local link {href!r}")
                continue
            if fragment and target.suffix.lower() == ".html":
                target_parser = parsed_pages.get(target.resolve())
                if target_parser is None:
                    target_parser = parse_page(target)
                    parsed_pages[target.resolve()] = target_parser
                if fragment not in set(target_parser.ids):
                    errors.append(
                        f"{page.relative_to(root)}: missing anchor #{fragment} in "
                        f"{target.relative_to(root) if target.is_relative_to(root) else target}"
                    )
    return errors


def validate_json_files(root: Path) -> list[str]:
    errors: list[str] = []
    for path in sorted(root.rglob("*.json")):
        try:
            json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            errors.append(f"{path.relative_to(root)}: invalid JSON: {exc}")
    for path in sorted(root.rglob("*.jsonl")):
        line_number = 0
        try:
            for line_number, line in enumerate(
                path.read_text(encoding="utf-8").splitlines(), start=1
            ):
                if line.strip():
                    json.loads(line)
        except (OSError, json.JSONDecodeError) as exc:
            errors.append(f"{path.relative_to(root)}:{line_number}: invalid JSONL: {exc}")
    return errors


def validate_public_evals(root: Path) -> list[str]:
    errors: list[str] = []
    for path in sorted(root.rglob("evals/evals.json")):
        rel = path.relative_to(root)
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        if payload.get("skill_name") != "prax-teach-v2":
            errors.append(f"{rel}: skill_name must be 'prax-teach-v2'")
        if payload.get("fixture_visibility") != "public_development_only":
            errors.append(f"{rel}: fixtures must be labeled public_development_only")
        evals = payload.get("evals")
        if not isinstance(evals, list) or not evals:
            errors.append(f"{rel}: evals must be a non-empty list")
            continue
        seen_ids: set[str] = set()
        for index, item in enumerate(evals):
            label = f"{rel}:evals[{index}]"
            if not isinstance(item, dict):
                errors.append(f"{label}: expected an object")
                continue
            eval_id = item.get("id")
            if not isinstance(eval_id, str) or not eval_id.strip():
                errors.append(f"{label}: id must be a non-empty string")
            elif eval_id in seen_ids:
                errors.append(f"{label}: duplicate id {eval_id!r}")
            else:
                seen_ids.add(eval_id)
            for field in ("prompt", "expected_output"):
                value = item.get(field)
                if not isinstance(value, str) or not value.strip():
                    errors.append(f"{label}: {field} must be a non-empty string")
            assertions = item.get("assertions")
            if not isinstance(assertions, list) or not assertions or not all(
                isinstance(value, str) and value.strip() for value in assertions
            ):
                errors.append(f"{label}: assertions must be a non-empty string list")
    return errors


def validate_flint_specs(root: Path) -> list[str]:
    errors: list[str] = []
    for path in sorted(root.rglob("*.flint.json")):
        rel = path.relative_to(root)
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        if not isinstance(payload, dict):
            errors.append(f"{rel}: Flint spec must be an object")
            continue
        data = payload.get("data")
        semantic_types = payload.get("semantic_types")
        chart_spec = payload.get("chart_spec")
        if not isinstance(data, dict) or not ({"values", "url"} & set(data)):
            errors.append(f"{rel}: data must contain values or url")
        elif isinstance(data.get("url"), str) and data["url"].startswith(("http://", "https://")):
            errors.append(f"{rel}: remote data URLs are not allowed in durable Flint specs")
        if not isinstance(semantic_types, dict) or not semantic_types:
            errors.append(f"{rel}: semantic_types must be a non-empty object")
        if not isinstance(chart_spec, dict):
            errors.append(f"{rel}: chart_spec must be an object")
            continue
        if not isinstance(chart_spec.get("chartType"), str) or not chart_spec["chartType"].strip():
            errors.append(f"{rel}: chart_spec.chartType must be a non-empty string")
        if not isinstance(chart_spec.get("encodings"), dict) or not chart_spec["encodings"]:
            errors.append(f"{rel}: chart_spec.encodings must be a non-empty object")
    return errors


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("workspace", type=Path)
    args = parser.parse_args()
    root = args.workspace.expanduser().resolve()
    if not root.is_dir():
        print(f"error: not a directory: {root}", file=sys.stderr)
        return 2

    markdown_files = sorted(root.rglob("*.md"))
    errors: list[str] = []
    for path in markdown_files:
        text = path.read_text(encoding="utf-8")
        if "[TODO" in text or "TODO:" in text:
            errors.append(f"{path.relative_to(root)}: unresolved TODO placeholder")
        errors.extend(validate_html_pair(path, root))

    all_html_files = sorted(root.rglob("*.html"))
    html_files = [path for path in all_html_files if path.name != "index.html"]
    errors.extend(validate_local_links(all_html_files, root))
    for index_path in (path for path in all_html_files if path.name == "index.html"):
        index_parser = parse_page(index_path)
        index_rel = index_path.relative_to(root)
        if not {"header", "main", "footer"}.issubset(index_parser.tags):
            errors.append(f"{index_rel}: required landmarks missing")
        if not all(
            [
                index_parser.has_lang,
                index_parser.has_charset,
                index_parser.has_viewport,
                index_parser.has_title,
                index_parser.has_skip_link,
            ]
        ):
            errors.append(f"{index_rel}: required document metadata or skip link missing")
        if len(index_parser.ids) != len(set(index_parser.ids)):
            errors.append(f"{index_rel}: duplicate IDs")
        for problem in check_heading_order(index_parser.heading_levels):
            errors.append(f"{index_rel}: {problem}")
        if index_parser.external_assets:
            errors.append(f"{index_rel}: mandatory external assets: {index_parser.external_assets}")
    errors.extend(validate_json_files(root))
    errors.extend(validate_public_evals(root))
    errors.extend(validate_flint_specs(root))

    if errors:
        print(f"FAILED: {len(errors)} problem(s)")
        for error in errors:
            print(f"- {error}")
        return 1

    print(
        f"PASS: {len(markdown_files)} Markdown/HTML pair(s), "
        f"{len(html_files)} companion page(s), JSON/eval/spec checks, and local links"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
